package aGrandeFamilia;

import java.util.Scanner;

public class Programa {
		//Nome: Gabriel Rentschler de Araujo	RM:86028
		//Nome: Gyovanna Oliveira Carvalho		RM:85281
		//Nome: �talo Vellasco Venturini		RM:84828
		//Nome: Lucas Piran						RM:85717
		
	
		 public static boolean numerosPrimo (int numero){
		        
			 if(numero == 0 || numero == 1) {
				 return false;
			 }
			 
		        for(int p=2; p<numero; p++){
		            if(numero % p == 0){
		                return false;
		            }
		        }
		        return true;
		    }
		    
		 public static int[] listaCrescente (int[] lista_unica) {
		        int pos = 0;
		        int temp = 0;
		        int[] lista_final = new int[lista_unica.length];
		        
		        for(int x=0;x<lista_final.length;x++) {
		        	lista_final[x] = lista_unica[x];
		        }
		        
		        while(pos < 14) {
		        	pos = 0;
		        	for(int x=0;x<(lista_final.length-1);x++) {
		        		if(lista_final[(x+1)] < lista_final[x] ) {
		        			temp = lista_final[x];
		        			lista_final[x] = lista_final[(x+1)];
		        			lista_final[(x+1)] = temp;
		        			break;
		        		}
		        		pos++;
		        	}
		        }
		        return lista_final;
		    }
		
		public static void main(String[] args) {
			 int[] lista1 = new int[5];
		        int[] lista2 = new int[5];
		        int[] lista3 = new int[5];
		        int[] lista_unica = new int[15];
		        int[] lista_final = new int[lista_unica.length];
		        int[] minutos = new int[99];
		        int y = 0, hora = 0, min = 0, a = 0;
		        boolean repete = false;
		        
		        Scanner leitor = new Scanner(System.in);
		        
		        //Minutos como n�meros aleat�rios
		        for(int x=0;x<minutos.length;x++) {
		            if(numerosPrimo((x+1))) {
		            	minutos[a] = x+1;
		            	a++;
		            }
		        }
		        
		        //Input do Cliente
		        for(int x=0; x<lista1.length;x++){
		        
		            System.out.println("Por favor, digite os numeros das salas a serem desinfetadas para a 1� lista (salas 1 a 99):");
		            lista1[x] = leitor.nextInt();
		            
		        }
		        for(int x=0; x<lista2.length;x++){
		        
		            System.out.println("Por favor, digite os numeros das salas a serem desinfetadas para a 2� lista (salas 1 a 99):");
		            lista2[x] = leitor.nextInt();
		            
		        }
		        for(int x=0; x<lista3.length;x++){
		        
		            System.out.println("Por favor, digite os numeros das salas a serem desinfetadas para a 3� lista (salas 1 a 99):");
		            lista3[x] = leitor.nextInt();
		            
		        }
		        
		        //Colocar as 3 listas em uma �nica lista
		        for(int x=0; x<lista1.length;x++){
		            
		            for(int z=0;z<lista_unica.length;z++) {
		        		if(lista1[x]==lista_unica[z]) {
		        			repete = true;
		        		}
		        	}
		        	
		        	if(repete == false) {
		        		lista_unica[y] = lista1[x];
		        		y++;
		        	} else {
		        		repete = false;
		        	}
		        	
		        	for(int z=0;z<lista_unica.length;z++) {
		        		if(lista2[x]==lista_unica[z]) {
		        			repete = true;
		        		}
		        	}
		        	if(repete == false) {
		        		lista_unica[y] = lista2[x];
		        		y++;
		        	} else {
		        		repete = false;
		        	}
		        	
		        	for(int z=0;z<lista_unica.length;z++) {
		        		if(lista3[x]==lista_unica[z]) {
		        			repete = true;
		        		}
		        	}
		        	if(repete == false) {
		        		lista_unica[y] = lista3[x];
		        		y++;
		        	} else {
		        		repete = false;
		        	}
		           
		        }
		        
		        //Chamada da Lista Crescente
		        lista_final = listaCrescente(lista_unica);
		        
		        //Print das listas e minutos
		        System.out.print("Salas: ");
		        for(int x=0; x<lista_unica.length;x++){
		        	if(lista_unica[x] != 0) {
		        		System.out.print(lista_unica[x] + ", ");
		        		
		        		min+=minutos[x];
		        	}
		        	
		        	if(min >= 60) {
			                min -= 60;
			                hora++;
			        }
		        }
		        
		        System.out.println(" ");
		        System.out.print("Salas em ordem crescente: ");
		        for(int x=0; x<lista_unica.length;x++){
		        	if(lista_final[x] != 0) {
		        		System.out.print(lista_final[x] + ", ");
		        	}
		        }
		        System.out.println(" ");
		        System.out.print("Minutos para cada sala:");
		        for(int x=0; x<lista_unica.length;x++) {
		        	if(lista_unica[x] != 0) {
		        		System.out.print(minutos[x]+", ");
		        	}
		        }
		        System.out.println(" ");
		        System.out.println("Tempo total: " + hora + " horas " + " e " + min  + " minutos.");
		        
		        leitor.close();
	    }
}
